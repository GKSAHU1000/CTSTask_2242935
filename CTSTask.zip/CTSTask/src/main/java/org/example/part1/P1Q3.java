package org.example.part1;


/*

                  3. Runnable Using Lambda:
                  • Create a new thread using the Runnable interface and lambda expressions.
                  The thread should print "Lambda Runnable in action!" when run.
*/
public class P1Q3 {


    public static void main(String[] args) {

        //1 Method
        Runnable runnable = ()->{
            System.out.println("Lambda Runnable in action!");
        };
        new Thread(runnable).start();

        //2- Method

        new Thread(()->{
            System.out.println("Lambda Runnable in action!");
        }).start();


        //3- Method

      Thread thread=   new Thread(()->{
            System.out.println("Lambda Runnable in action!");
        });

      thread.start();

    }
}
