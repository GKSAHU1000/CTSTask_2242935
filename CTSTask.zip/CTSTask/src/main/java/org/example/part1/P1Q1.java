package org.example.part1;



interface Calculate {
    int sum(int a, int b);
}

interface Utility {
    String makeUpperCase(String str);
}

public class P1Q1 {
/*

1. Basic Lambda Expressions:
• Write a lambda expression that takes two integers and returns their sum.
• Write a lambda expression that takes a string and returns its uppercase version.
*/
    public static void main(String[] args) {

       // Write a lambda expression that takes two integers and returns their sum.
        System.out.println("sum of two num using lambda expression  ");
        Calculate calculate = (a, b) -> a + b;
        int a= 10, b=20;
        int sum = calculate.sum(a, b);
        System.out.println(a+"+"+b+" : "+ sum);
        System.out.println();

        /*------------------------------------------------------*/


        //Write a lambda expression that takes a string and returns its uppercase version.
        Utility utility = (str)-> str.toUpperCase();
        String str1 = "gulshan";
        String resultstr1 = utility.makeUpperCase(str1);
        System.out.println(str1+ " in Uppercase = "+resultstr1);


        System.out.println();

//        //Using Method Reference
//        Utility utility1 = String::toUpperCase;
//        String str2 = "gulshan";
//        String resultstr2 = utility1.makeUpperCase(str2);
//        System.out.println(str1+ " in Uppercase = "+resultstr2);


    }
}
