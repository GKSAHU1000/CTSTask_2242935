package org.example.part1;

import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class P1Q2 {

    /*
    2.Comparator Using Lambda:
     • Given a list of strings, sort them based on their length using a lambda expression.
    */

    public static void main(String[] args) {

        List<String> list = Arrays.asList("a", "abcd", "abcde", "ab", "abc", "abcdef");

        System.out.println("Before sort : "+ list);

        //sorting list of string Using comparator and Lambda exp. compare the length of string
        Collections.sort(list,(obj1,obj2)->Integer.compare(obj1.length(),obj2.length()));


        System.out.println("After sort : "+ list);


    }
}
