package org.example.part2;

import java.util.function.BiFunction;
import java.util.function.Function;

/*

Function Composition:
• Create two Function<Integer, Integer> definitions:
    a. One that multiplies the given number by 2.
    b. Another that adds 3 to the given number.
• Compose the two functions into a new function that multiplies a given number by 2 and then adds 3.

*/
public class P2Q3 {

    public static void main(String[] args) {
        int num1 = 20;

        /*----------------------a. One that multiplies the given number by 2.----------------------------------------*/

        Function<Integer, Integer> multipliesby2 = (x) -> x * 2;
        int result1 = multipliesby2.apply(num1);
        System.out.println("given num = " + num1 + " multiply by 2 = " + result1);
        System.out.println("------------");



        /*-------------------------b. Another that adds 3 to the given number.-------------------------------------*/

        Function<Integer, Integer> addby3 = (a) -> a + 3;
        int result2 = addby3.apply(num1);
        System.out.println("given num = " + num1 + " add by 3 = " + result2);
        System.out.println("------------");


        /*----------------------Combine Both----------------------------------------*/
        //Compose the two functions into a new function that multiplies a given number by 2 and then adds 3.
        Function<Integer, Integer> composeReturn = multipliesby2.andThen(addby3);
        int result3 = composeReturn.apply(num1);
        System.out.println("Compose the both functions : " + result3);


    }
}
