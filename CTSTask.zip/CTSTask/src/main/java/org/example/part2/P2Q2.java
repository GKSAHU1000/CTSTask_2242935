package org.example.part2;


import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Optional;

/*
Map-Filter-Reduce:
• Using a list of strings, convert all strings to uppercase (map), filter out strings
that are less than 4 characters long, and concatenate the remaining strings
(reduce).
*/
public class P2Q2 {

    public static void main(String[] args) {

        List<String> list = Arrays.asList("one","two","three", "four","five", "test3467786", "test34", "test57897", "test645464564");

        Optional<String> reduce = list.stream()
                //Make Uppercase all
                 .map(x -> x.toUpperCase())
                    //Filter less than 4 characters long
                 .filter(x -> x.length() < 4)
                   //concatenate using reduce
                 .reduce((x, y) -> x + y);


        reduce.ifPresent(System.out::println);

    }
}
