package org.example.part2;


import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/*
* Part 2: Functional Programming
1. Streams:
• Convert a list of integers into a stream, filter out the odd numbers, and collect
the result into a new list.
*
* */
public class P2Q1 {


    public static void main(String[] args) {

        List<Integer> list = Arrays.asList(1, 2, 5, 7, 9, 3, 4, 6, 0);

        //Using filter predicate
        List<Integer> collect = list.stream().filter(x -> x % 2 != 0).collect(Collectors.toList());
        System.out.println(collect);

    }
}
