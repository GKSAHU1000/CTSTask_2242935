package org.example.part3;


import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.function.Consumer;
import java.util.function.Supplier;

/*
Consumer and Supplier:
• Write a consumer that prints the string it receives.
• Write a supplier that returns the current date-time as a formatted string.
* */
public class P3Q3 {

    public static void main(String[] args) {

        //Write a consumer that prints the string it receives.
        System.out.println("consumer that prints the string it receives.");

        //create a consumer to print the given parameter
        Consumer<String> consumer1 = (x) -> System.out.println("received value is " + x);
        String str = "gulshan";

        //consumer accept the given string
        consumer1.accept(str);

        System.out.println();


        // Write a supplier that returns the current date-time as a formatted string.
        System.out.println("supplier that returns the current date-time as a formatted string.");

        //creating a supplier to return a data time in formatted string
        Supplier<String> currentDateTime = () -> {
            LocalDateTime localDateTime = LocalDateTime.now();
            DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("dd-MMM-yyyy hh:mm:ss a");
            return localDateTime.format(dateTimeFormatter);
        };


        //calling the Supplier and return the date and time in formatted string
        String datetimetostr = currentDateTime.get();
        System.out.println("Current Date Time  as a formatted : " + datetimetostr);

    }
}
