package org.example.part3;


/*2. Function Interface:
• Write a function that takes a string and returns its length.
• Write a function that takes a string and returns its lowercase version.*/

@FunctionalInterface
interface Utility1 {
    int returnLength(String str);
}

@FunctionalInterface
interface Utility2 {
    String returnLowerCase(String str);
}

public class P3Q2 {


    public static void main(String[] args) {

        /*• Write a function that takes a string and returns its length.*/
        System.out.println(" Function that takes a string and returns its length.");
        String  str1= "gulshan";

        //using lambda in functional interface to return string length
        Utility1 utility = (str)->str.length();
        //call the returnLength using interface object
        int countstr = utility.returnLength(str1);
        System.out.println("string - "+str1+" length is : "+countstr);
        System.out.println();

        /*• Write a function that takes a string and returns its lowercase version.*/
        System.out.println("Function that takes a string and returns its lowercase version");
        String str2 = "GULSHAN";
        //using lambda in functional interface return given string to lowercase
        Utility2 utility2 = (str -> str.toLowerCase());
        System.out.println("before : "+str2);
        //call the retunLowercase using interface object
        String lowerasestr = utility2.returnLowerCase(str1);
        System.out.println("after lower case : "+lowerasestr);
    }

}
