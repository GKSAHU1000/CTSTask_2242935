package org.example.part3;

import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

/*Part 3: Using Pre-defined Functional Interfaces
1. Predicates:
• Write a predicate that checks if a number is even.
• Write a predicate that checks if a string's length is greater than 5.
• Combine the two predicates to check a list of strings and filter out those that
are even in length and have a length greater than 5.
*/
public class P3Q1 {
    public static void main(String[] args) {

        //predicate that checks if a number is even.
        System.out.println("predicate that checks if a number is even");
        List<Integer> listInt = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);
        System.out.println("before  all num list "+listInt);
        //cratering predicate function for even number
        Predicate<Integer> numIsEven = i -> (i % 2 == 0);

        //Using stream filter predicate  filter only the even number
        List<Integer> evennumlist = listInt.stream().filter(numIsEven).toList();
        System.out.println("after Even num list "+evennumlist);
        System.out.println();



        // Write a predicate that checks if a string's length is greater than 5
        System.out.println("Predicate that checks if a string's length is greater than 5");
        List<String> listStr = Arrays.asList("ab", "abc", "abcd", "abcde", "abcdef", "abcdefg", "abcdefgh");
        System.out.println("before List "+listStr);
        Predicate<String> lengthCheckGreaterFive = str -> (str.length() > 5);
        //Using filter predicate function filter the string based on length
        List<String> result2  = listStr.stream().filter(lengthCheckGreaterFive).toList();
        System.out.println("after filter list "+result2);
        System.out.println();



        //Combine the two predicates to check a list of strings and filter out those that
        //are even in length and have a length greater than 5
        System.out.println("Combine the two predicates to check a list of strings and filter out those that are even in length and have a length greater than 5");
        List<String> listStr2 = Arrays.asList("ab", "abc", "abcd", "abcde", "abcdef", "abcdefg", "abcdefgh");
        System.out.println("before "+listStr2);

        //Predicate for string length even number
        Predicate<String> strlengthIsEven = i -> (i.length() % 2 == 0);

        //Predicate for string length is greater then 5
        Predicate<String> strlengthCheckGreaterFive = str -> (str.length() > 5);

        //Combine both Predicate function
        Predicate<String> combine = strlengthIsEven.and(strlengthCheckGreaterFive);

        //filtering the list with both combine predicate function
        List<String> result3 = listStr2.stream().filter(combine).toList();

        System.out.println("after filter list "+result3);

    }

}
